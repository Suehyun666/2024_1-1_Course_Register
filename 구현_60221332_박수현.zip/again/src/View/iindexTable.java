package View;

public interface iindexTable {
	public void show(String link);
}
