/**
 * 
 */
/**
 * 
 */
module again {
	requires java.desktop;
	requires java.sql;
	requires java.xml.crypto;
	requires commons.codec;
}