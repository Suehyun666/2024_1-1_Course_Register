package Main;

import View.LoginFrame;

import View.Vmainframe;


public class main {
	//attributes 
	
	//components 
	private Vmainframe vmainframe;
	private LoginFrame loginframe;
	
	//constructors
	public main() {
		this.loginframe=new LoginFrame();
		this.loginframe.setVisible(true);
		
	}
	
	//main
	public static void main(String[] args) {
		main main =new main();
		main.initialize();
		main.run();

	}
	//methods
	private void run() {}
	
	//initialize
	private void initialize() {
		
		this.loginframe.initialize();
		//this.vmainframe.initialize();
	}

}
